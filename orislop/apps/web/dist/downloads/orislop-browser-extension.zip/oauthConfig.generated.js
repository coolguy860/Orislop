globalThis.OrislopOAuthConfig = Object.freeze({
  googleClientId: "",
  scopes: Object.freeze(["openid", "email", "profile"])
});
